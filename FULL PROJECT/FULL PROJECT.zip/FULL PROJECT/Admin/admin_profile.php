<!DOCTYPE html>
<html>

<head>

<title>Admin Profile</title>

<link rel = "stylesheet" type="text/css" href="page.css">

</head>

<body>
    <div class="menu-bar">

    <ul>
    <li><a href="home_page.php">Home</a></li>
    <li><a href="about_minstry.php">About Minstry</a></li>
    <li><a href="minstry.php">Minstries</a></li>
    <li><a href="recruit.php">Recruit</a></li>
    <li><a href="contact.php">Contact</a></li>
    <li><a herf = "admin_profile.php">Admin Profile</a></li>
    <li><a href="login.php">Log out</a></li>
    </ul>
    </div>


    </ul>
    </div>
    <marquee><a href="notice.php">Notice</a></marquee>

    <marquee></marquee>

    <div class="apply">
    <ul>   

    <table align ="center" cellpadding="10">

    <tr>
    <td>First Name:</td>
    <td><input type="text" id="name" name="name" placeholder="Enter your First Nmae"></td>
    </tr>
    

    <tr>
    <td>Last Name:</td>
    <td><input type="text" id="name" name="name" placeholder="Enter your Last Nmae"></td>
    </tr>

    <tr>
    <td>Email:</td>
    <td><input type="email" id="name" name="email" placeholder="Enter your Email"></td>
    </tr>

    <tr>
    <td>Bio:</td>
    <td><textarea rows="2" cols="24" placeholder="Bio"></textarea></td>
    </tr>


    <tr>
    <td>Date of Birth</td>
    <td><input type="date" id="name" name="DOB"></td>
    </tr>

    <tr>
    <td>Mobile Number:</td>
    <td><input type="number" id="name" name="MNUM" placeholder="Enter Mobile Number"></td>
    </tr>

    <tr>
    <td>Address:</td>
    <td><textarea rows="6" cols="25" placeholder="Address"></textarea></td>
    </tr>


</body>

</html>