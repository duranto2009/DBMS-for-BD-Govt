<!DOCTYPE html>
<html>

<head>

<title>Minstry of Land</title>

<link rel = "stylesheet" type="text/css" href="ministry_of_land.css">

</head>

<body>
    <div class="menu-bar">

    <ul>

    <li><a href="../home_page.php">Home</a></li>
    <li><a href="../about_minstry.php">About Minstry</a></li>
    <li><a href="../minstry.php">Minstries</a></li>
    <li><a href="../recruit.php">Recruit</a></li>
    <li><a href="../contact.php">Contact</a></li>
    <li><a href="#">Admin Profile</a></li>
    <li><a href="../login.php">Log out</a></li>

    </ul>
    </div>
    <marquee><a href="../notice.php">Notice</a></marquee>
 

</body>

</html>