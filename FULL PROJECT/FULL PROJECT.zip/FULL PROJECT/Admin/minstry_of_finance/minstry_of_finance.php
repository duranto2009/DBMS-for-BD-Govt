<!DOCTYPE html>
<html>

<head>

<title>Minstry of Finance</title>

<link rel = "stylesheet" type="text/css" href="minstry_of_finance.css">

</head>

<body>
    <div class="menu-bar">

    <ul>

    <li><a href="../home_page.php">Home</a></li>
    <li><a href="../about_minstry.php">About Minstry</a></li>
    <li><a href="../minstry.php">Minstries</a></li>
    <li><a href="../recruit.php">Recruit</a></li>
    <li><a href="../contact.php">Contact</a></li>
    <li><a href="../admin_profile.php">Admin Profile</a></li>
    <li><a href="../login.php">Log out</a></li>

    </ul>
    </div>
 <marquee><a href="../notice.php">Notice</a></marquee>
 

 <p>Minsry of bangladesh holds the hight position to make law and take any kind of disicion for Bangladesh</p>

</body>

</html>