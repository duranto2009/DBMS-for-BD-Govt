<!DOCTYPE html>
<html>

<head>

<title>Apply</title>

<link rel = "stylesheet" type="text/css" href="page.css">

</head>

<body>
    <div class="menu-bar">

    <ul>

    <li><a href="home_page.php">Home</a></li>
    <li><a href="about_minstry.php">About Minstry</a></li>
    <li><a href="minstry.php">Minstries</a></li>
    <li><a href="apply.php">Apply</a></li>
    <li><a href="contact.php">Contact</a></li>
    <li><a href="user_profile.php">User Profile</a></li>
    <li><a href="login.php">Log out</a></li>

    </ul>
    </div>
    <marquee><a href="notice.php">Notice</a></marquee>

    <marquee></marquee>

    <div class="apply">
    <ul>   

    <table align ="center" cellpadding="10">

    <tr>
    <td>First Name:</td>
    <td><input type="text" id="name" name="name" placeholder="Enter your First Nmae"></td>
    </tr>
    

    <tr>
    <td>Last Name:</td>
    <td><input type="text" id="name" name="name" placeholder="Enter your Last Nmae"></td>
    </tr>

    <tr>
    <td>Email:</td>
    <td><input type="email" id="name" name="email" placeholder="Enter your Email"></td>
    </tr>


    <tr>
    <td>Date of Birth</td>
    <td><input type="date" id="name" name="DOB"></td>
    </tr>

    <tr>
                            <td>Mobile Number:</td>
                            <td><input type="number" id="name" name="MNUM" placeholder="Enter Mobile Number"></td>
    </tr>


    <tr>
                            <td>NID Number:</td>
                            <td><input type="number" id="name" name="NID" placeholder="Enter NID Number"></td>
    </tr>


    <tr>
                          <td align="left" valign="middle">&nbsp;</td>
                          <td>Minstry</td>
                          <td align="left" valign="middle">:</td>
                          <td align="right" valign="middle"><select name="apply_minstry" class="textfield05" id="apply_minstry">
                          <option value="" selected="">Select One</option>
						  <option value="Ministry of Public Administration">Ministry of Public Administration</option>
						  <option value="Ministry of Defence">Ministry of Defence</option>
						  <option value="Armed Forces Division">Armed Forces Division</option>
                          <option value="Ministry of Power, Energy and Mineral Resources">Ministry of Power, Energy and Mineral Resources</option>
						  <option value="Minstry of Finance">Minstry of Finance</option>
						  <option value="Ministry of Industries">Ministry of Industries</option>
						  <option value="Ministry of Commerce">Ministry of Commerce</option>
                          <option value="Ministry of Agriculture">Ministry of Agriculture</option>
                          <option value="Ministry of Home Affairs">Ministry of Home Affairs</option>
                          <option value="Ministry of Health and Family Welfare">Ministry of Health and Family Welfare</option>
						  <option value="Ministry of Local Government, Rural Development and Co-operatives">Ministry of Local Government, Rural Development and Co-operatives</option>
						  <option value="Ministry of Science and Technology">Ministry of Science and Technology</option>
                          <option value="Ministry of Fisheries and Livestock">Ministry of Fisheries and Livestock</option>
                          <option value="Ministry of Liberation War Affairs">Ministry of Liberation War Affairs</option>
                          <option value="Ministry of Textiles and Jute">Ministry of Textiles and Jute</option>
                          <option value="Ministry of Road Transport and Bridges">Ministry of Road Transport and Bridges</option>
                          <option value="Ministry of Information">Ministry of Information</option>
                          <option value="Ministry of Environment and Forest">Ministry of Environment and Forest</option>
                          <option value="Ministry of Education">Ministry of Education</option>
                          <option value="Ministry of Law, Justice and Parliamentary Affairs">Ministry of Law, Justice and Parliamentary Affairs</option>
                          <option value="Ministry of Foreign Affairs">Ministry of Foreign Affairs</option>
                          <option value="Ministry of Railways">Ministry of Railways</option>
                          <option value="Ministry of Planning">Ministry of Planning</option>
                          <option value="Posts and Telecommunications Division">Posts and Telecommunications Division</option>
                          <option value="Ministry of Land">Ministry of Land</option>
                          <option value="Ministry of Food">Ministry of Food</option>
                          <option value="Ministry of Social Welfare">Ministry of Social Welfare</option>
                          <option value="Ministry of Chittagong Hill Tracts Affairs">Ministry of Chittagong Hill Tracts Affairs</option>
                          <option value="Ministry of Expatriates' Welfare and Overseas Employment">Ministry of Expatriates' Welfare and Overseas Employment</option>
                          <option value="Ministry of Water Resources">Ministry of Water Resources</option>
                          <option value="Ministry of Housing and Public Works">Ministry of Housing and Public Works</option>
                          <option value="Ministry of Civil Aviation and Tourism">Ministry of Civil Aviation and Tourism</option>
                          <option value="Ministry of Religious Affairs">Ministry of Religious Affairs</option>
                          <option value="Ministry of Women and Children Affairs">Ministry of Women and Children Affairs</option>
                          <option value="Information and Communication Technology Division">Information and Communication Technology Division</option>
                          <option value="Ministry of Labour and Employment">Ministry of Labour and Employment</option>
                          <option value="Ministry of Youth and Sports">Ministry of Youth and Sports</option>
                          <option value="Ministry of Cultural Affairs">Ministry of Cultural Affairs</option>
                          <option value="Ministry of Primary and Mass Education">Ministry of Primary and Mass Education</option>
                          <option value="Ministry of Shipping">Ministry of Shipping</option>
                          <option value="Ministry of Disaster Management and Relief">Ministry of Disaster Management and Relief</option>



                          </select></td>
                          <td align="left" valign="middle">&nbsp;</td>
                        </tr>




                        <tr>
                          <td align="left" valign="middle">&nbsp;</td>
                          <td>Grade</td>
                          <td align="left" valign="middle">:</td>
                          <td align="right" valign="middle"><select name="apply_minstry" class="textfield05" id="apply_minstry">
                          <option value="" selected="">Select One</option>
						  <option value="1st">1st</option>
						  <option value="2nd">2nd</option>
						  <option value="3rd">3rd</option>
                          <option value="4th">4th</option>
						  <option value="5th">5th</option>
						  <option value="6th">6th</option>
						  <option value="7th">7th</option>
                          <option value="8th">8th</option>
                          <option value="9th">9th</option>
                          </select></td>
                          <td align="left" valign="middle">&nbsp;</td>
                        </tr>

                        <tr>
                          <td align="left" valign="middle">&nbsp;</td>
                          <td align="left" valign="middle">City</td>
                          <td align="left" valign="middle">:</td>
                          <td align="right" valign="middle"><select name="city" class="textfield05" id="city">
                          <option value="" selected="">Select One</option>
						  <option value="barisal">Barisal</option>
						  <option value="chittagong">Chittagong</option>
						  <option value="comilla">Comilla</option>
                          <option value="dhaka">Dhaka</option>
						  <option value="dinajpur">Dinajpur</option>
						  <option value="jessore">Jessore</option>
						  <option value="mymensingh">Mymensingh</option>
                          <option value="rajshahi">Rajshahi</option>
                          <option value="sylhet">Sylhet</option>
                          </select></td>
                          <td align="left" valign="middle">&nbsp;</td>
                        </tr>


                        <tr>
                        <td align="center" colspan="2">
                        <input type="submit" value="Submit">
                        &nbsp;&nbsp; <input type="submit" value="Reset">


                        </td>
                        
                        
                        
                        </tr>

    </table>



    </ul>
   
</body>

</html>