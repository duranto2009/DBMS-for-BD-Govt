<!DOCTYPE html>
<html>

<head>

<title>Ministry of Road Transport and Bridges</title>

<link rel = "stylesheet" type="text/css" href="ministry_of_road_transport_and_bridges.css">

</head>

<body>
    <div class="menu-bar">

    <ul>

    <li><a href="../home_page.php">Home</a></li>
    <li><a href="../about_minstry.php">About Minstry</a></li>
    <li><a href="../minstry.php">Minstries</a></li>
    <li><a href="../apply.php">Apply</a></li>
    <li><a href="../contact.php">Contact</a></li>
    <li><a href="../user_profile.php">User Profile</a></li>
    <li><a href="../login.php">Log out</a></li>

    </ul>
    </div>
    <marquee><a href="../notice.php">Notice</a></marquee>
 

</body>

</html>