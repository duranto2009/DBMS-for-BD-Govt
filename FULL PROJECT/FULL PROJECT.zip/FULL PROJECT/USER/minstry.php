<!DOCTYPE html>
<html>

<head>

<title>Minstries</title>

<link rel = "stylesheet" type="text/css" href="page.css">

</head>

<body>
    <div class="menu-bar">

    <ul>

    <li><a href="home_page.php">Home</a></li>
    <li><a href="about_minstry.php">About Minstry</a></li>
    <li><a href="minstry.php">Minstries</a></li>
    <li><a href="apply.php">Apply</a></li>
    <li><a href="contact.php">Contact</a></li>
    <li><a href="user_profile.php">User Profile</a></li>
    <li><a href="login.php">Log out</a></li>
    
    </ul>
    

    <marquee><a href="notice.php">Notice</a></marquee>
    <marquee></marquee>



    <div class="mins-1">
    <ul>    

    <li><a href="ministry_of_public_administration/ministry_of_public_administration.php">Ministry of Public Administration</a></li>
    <li><a href="ministry_of_defence/ministry_of_defence.php">Ministry of Defence</a></li>
    <li><a href="armed_forces_division/armed_forces_division.php">Armed Forces Division</a></li>
    <li><a href="ministry_of_power_energy_and_mineral_resources/ministry_of_power_energy_and_mineral_resources.php">Ministry of Power, Energy and Mineral Resources</a></li>
    <li><a href="minstry_of_finance/minstry_of_finance.php">Minstry of Finance</a></li>
    <li><a href="ministry_of_industries/ministry_of_industries.php">Ministry of Industries</a></li>


    </ul>

    <marquee></marquee>
    <marquee></marquee>

    <div class="mins-2">
<ul>    

    <li><a href="ministry_of_commerce/ministry_of_commerce.php">Ministry of Commerce</a></li>
    <li><a href="ministry_of_agriculture/ministry_of_agriculture.php">Ministry of Agriculture</a></li>
    <li><a href="ministry_of_home_affairs/ministry_of_home_affairs.php">Ministry of Home Affairs</a></li>
    <li><a href="ministry_of_health_and_family_welfare/ministry_of_health_and_family_welfare.php">Ministry of Health and Family Welfare</a></li>
    <li><a href="ministry_of_local_government_rural_development_and_co-operatives/ministry_of_local_government_rural_development_and_co-operatives.php">Ministry of Local Government, Rural Development and Co-operatives</a></li>
    <li><a href="ministry_of_science_and_technology/ministry_of_science_and_technology.php">Ministry of Science and Technology</a></li>
    
    
</ul>


    <marquee> </marquee>
    <marquee> </marquee>

    <div class="mins-3">
<ul>    

    <li><a href="ministry_of_fisheries_and_llvestock/ministry_of_fisheries_and_llvestock.php">Ministry of Fisheries and Livestock</a></li>
    <li><a href="ministry_of_liberation_war_affairs/ministry_of_liberation_war_affairs.php">Ministry of Liberation War Affairs</a></li>
    <li><a href="ministry_of_textiles_and_jute/ministry_of_textiles_and_jute.php">Ministry of Textiles and Jute</a></li>
    <li><a href="ministry_of_road_transport_and_bridges/ministry_of_road_transport_and_bridges.php">Ministry of Road Transport and Bridges</a></li>
    <li><a href="ministry_of_information/ministry_of_information.php">Ministry of Information</a></li>
    <li><a href="ministry_of_environment_and_forest/ministry_of_environment_and_forest.php">Ministry of Environment and Forest</a></li>
    
    
</ul>


    <marquee> </marquee>
    <marquee> </marquee>

    <div class="mins-4">
<ul>    


    <li><a href="ministry_of_education/ministry_of_education.php">Ministry of Education</a></li>
    <li><a href="ministry_of_law_justice_and_parliamentary_affairs/ministry_of_law_justice_and_parliamentary_affairs.php">Ministry of Law, Justice and Parliamentary Affairs</a></li>
    <li><a href="ministry_of_foreign_affairs/ministry_of_foreign_affairs.php">Ministry of Foreign Affairs</a></li>
    <li><a href="ministry_of_railways/ministry_of_railways.php">Ministry of Railways</a></li>  
    <li><a href="ministry_of_planning/ministry_of_planning.php">Ministry of Planning</a></li>
    <li><a href="posts_and_telecommunications_division/posts_and_telecommunications_division.php">Posts and Telecommunications Division</a></li>

</ul>


    <marquee> </marquee>
    <marquee> </marquee>

    <div class="mins-5">
<ul>    



    <li><a href="ministry_of_land/ministry_of_land.php">Ministry of Land</a></li>
    <li><a href="ministry_of_food/ministry_of_food.php">Ministry of Food</a></li>
    <li><a href="ministry_of_social_welfare/ministry_of_social_welfare.php">Ministry of Social Welfare</a></li>
    <li><a href="ministry_of_chittagong_hill_tracts_affairs/ministry_of_chittagong_hill_tracts_affairs.php">Ministry of Chittagong Hill Tracts Affairs</a></li>
    <li><a href="ministry_of_expatriates_welfare_and_overseas_employment/ministry_of_expatriates_welfare_and_overseas_employment.php">Ministry of Expatriates' Welfare and Overseas Employment</a></li>
    <li><a href="ministry_of_water_resources/ministry_of_water_resources.php">Ministry of Water Resources</a></li>
    
    
</ul>


    <marquee> </marquee>
    <marquee> </marquee>

    <div class="mins-6">
<ul>    

    <li><a href="ministry_of_housing_and_public_works/ministry_of_housing_and_public_works.php">Ministry of Housing and Public Works</a></li>
    <li><a href="ministry_of_civil_aviation_and_tourism/ministry_of_civil_aviation_and_tourism.php">Ministry of Civil Aviation and Tourism</a></li>
    <li><a href="ministry_of_religious_affairs/ministry_of_religious_affairs.php">Ministry of Religious Affairs</a></li>
    <li><a href="ministry_of_women_and_children_affairs/ministry_of_women_and_children_affairs.php">Ministry of Women and Children Affairs</a></li>
    <li><a href="information_and_communication_technology_division/information_and_communication_technology_division.php">Information and Communication Technology Division</a></li>
    <li><a href="ministry_of_labour_and_employment/ministry_of_labour_and_employment.php">Ministry of Labour and Employment</a></li>
    
</ul>



    <marquee> </marquee>
    <marquee> </marquee>

    <div class="mins-7">
<ul>    

    <li><a href="ministry_of_youth_and_sports/ministry_of_youth_and_sports.php">Ministry of Youth and Sports</a></li>
    <li><a href="ministry_of_cultural_affairs/ministry_of_cultural_affairs.php">Ministry of Cultural Affairs</a></li>
    <li><a href="ministry_of_primary_and_mass_education/ministry_of_primary_and_mass_education.php">Ministry of Primary and Mass Education</a></li>
    <li><a href="ministry_of_shipping/ministry_of_shipping.php">Ministry of Shipping</a></li>
    <li><a href="ministry_of_disaster_management_and_relief/ministry_of_disaster_management_and_relief.php">Ministry of Disaster Management and Relief</a></li>
    
    
</ul>


    





    </div>
    
</body>

</html>